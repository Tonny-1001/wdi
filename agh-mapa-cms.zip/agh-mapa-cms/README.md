# Mapa kampusu AGH 3D – wersja CMS dla WordPress

Ta wtyczka przenosi do bazy danych WordPress wszystkie 81 budynków i obiektów z przekazanego pliku `Kampus_AGH_mapa_3D_pineski_skorygowane(1).html`. Każdy budynek jest osobnym wpisem typu **Budynki AGH**. Przy pierwszej aktywacji zostaną zaimportowane oryginalne dane; później mapa pobiera je z bazy, a nie z HTML/JSON.

Wtyczka zachowuje interfejs oryginalnej strony: MapLibre, mapę 3D/2D, reset widoku, znaczniki budynków, wyszukiwarkę, filtrowanie, mobilne panele szczegółów, przekierowania do Google Maps/Apple Maps. Geometrie/punkty kalibracyjne z oryginału są zachowane w bazie. Mapa wymaga połączenia z internetem do pobrania zewnętrznych kafelków i biblioteki MapLibre (tak samo jak oryginał).

## Instalacja przez panel WordPress (najłatwiej)

1. Utwórz **kopię zapasową bazy WordPress** i strony, zwłaszcza przy aktualizacji istniejącej instalacji.
2. Otwórz `https://TWOJA-DOMENA/wp-admin` i zaloguj się jako administrator.
3. **Wtyczki → Dodaj nową wtyczkę → Wyślij wtyczkę na serwer**.
4. Wybierz plik `agh-mapa-cms.zip`, kliknij **Zainstaluj**, potem **Włącz**.
5. Z menu **Budynki AGH → Wszystkie budynki** powinno być dostępnych **81 pozycji**.
6. Utwórz w WordPress stronę, np. **Mapa kampusu**, dodaj blok **Krótki kod** i wpisz dokładnie:

   ```text
   [agh_mapa]
   ```

7. Opublikuj stronę. Domyślnie mapa zajmie cały ekran, dzięki czemu zachowuje układ oryginalnego pliku HTML.

Jeśli mapa ma być częścią standardowego layoutu WordPress, użyj:

```text
[agh_mapa tryb="osadzony" wysokosc="800px"]
```

## Instalacja bezpośrednio w kontenerze Docker

Jeśli nie masz dostępu do instalowania ZIP-a przez panel WordPress, możesz skopiować rozpakowany katalog wtyczki do kontenera.

1. Rozpakuj `agh-mapa-cms.zip` na swoim komputerze; powstanie katalog `agh-mapa-cms/`.
2. Ustal nazwę kontenera WordPress:

   ```bash
   docker ps
   ```

3. Skopiuj cały katalog (wpisz rzeczywistą nazwę kontenera zamiast `wordpress`):

   ```bash
   docker cp agh-mapa-cms wordpress:/var/www/html/wp-content/plugins/
   ```

4. W WordPress przejdź do **Wtyczki → Zainstalowane wtyczki** i kliknij **Włącz** przy **AGH – Mapa kampusu 3D (CMS)**.
5. Utwórz stronę z shortcode `[agh_mapa]`.

Jeżeli katalog `/var/www/html` jest zamontowany jako wolumen Docker lub bind mount, możesz zamiast `docker cp` umieścić `agh-mapa-cms/` w katalogu `wp-content/plugins/` na hoście. **Nie kopiuj plików bezpośrednio do kontenera tylko na chwilę, jeżeli po jego odtworzeniu mogłyby zostać utracone.** Sprawdź wolumeny w konfiguracji Compose i przechowuj kod w trwałym wolumenie lub podmontowanym katalogu.

Opcjonalne sprawdzenie plików w kontenerze:

```bash
docker exec wordpress ls -la /var/www/html/wp-content/plugins/agh-mapa-cms
```

## Edytowanie budynków w CMS

1. Zaloguj się do `/wp-admin`.
2. Kliknij **Budynki AGH → Wszystkie budynki**.
3. Wybierz np. `A-0` (lub dowolny inny rekord).
4. Tytuł wpisu zmienia nazwę budynku; treść pod edytorem tytułu może zawierać dodatkowy opis.
5. W panelu **Dane budynku i pineski (CMS)** możesz edytować kod, kategorię, kolor pineski, współrzędne WGS84, poziom weryfikacji, godziny otwarcia, źródło współrzędnych i wydziały/jednostki.
6. Kliknij **Aktualizuj**. Po odświeżeniu mapy zmiany będą widoczne bez przerabiania HTML i bez ponownego instalowania wtyczki.
7. Aby dodać nowy obiekt, kliknij **Budynki AGH → Dodaj budynek**, ustaw współrzędne geograficzne i **Opublikuj**.

W ustawieniach zaawansowanych edytujesz też oryginalną geometrię JSON, współrzędne planu, położenie etykiety oraz kolejność na liście. Budynki bez poprawnych współrzędnych **nie będą wyświetlane** do czasu ich uzupełnienia.

## Gdzie są zapisywane dane

- WordPress `wp_posts` (lub odpowiednik z własnym prefiksem): nazwa, opis, kolejność, stan publikacji, typ wpisu `agh_budynek`.
- WordPress `wp_postmeta`: kod, jednostki, kategoria, współrzędne, godziny, źródła, geometria, wygląd pineski, itd.
- WordPress `wp_options`: nieedytowane globalne dane planu z oryginalnego pliku oraz znacznik pierwszego importu.

`data/initial.json` to **tylko kopia danych startowych używana podczas pierwszej instalacji**. Na działającej stronie nie jest źródłem danych. Ręczne zmiany w panelu przechowuje baza WordPress. **Nie nadpisuj bazy startowym plikiem po wykonaniu edycji.**

Dane w WordPress pozostaną po wyłączeniu lub usunięciu wtyczki, ale zawsze wykonuj kopie zapasowe przed zmianami. Odtworzenie nowej, pustej bazy spowoduje ponowny import danych początkowych i nie odtworzy Twoich późniejszych edycji.

## Rozwiązywanie problemów

- **Na stronie wyświetla się `[agh_mapa]`:** włącz wtyczkę i upewnij się, że kod dodano w bloku „Krótki kod”.
- **Brak budynków:** sprawdź aktywację i publikację wpisów w „Budynki AGH”; po instalacji powinno być 81 obiektów.
- **Pineska się nie pojawia:** sprawdź szerokość i długość geograficzną (WGS84) oraz status wpisu „Opublikowano”.
- **Widać tło, ale nie widać mapy:** sprawdź dostęp do Internetu z przeglądarki, w tym `cdn.jsdelivr.net` i `tiles.openfreemap.org`. Wtyczka zachowuje te same zewnętrzne serwisy co oryginał.
- **Zmiana nie jest widoczna:** odśwież stronę z mapą, a jeśli korzystasz z cachingu strony/reverse proxy/CDN, wyczyść pamięć podręczną.

Ważne: oryginalne współrzędne były częściowo szacowane; zachowano je bez przenoszenia pinesek i bez nowej weryfikacji położenia.
