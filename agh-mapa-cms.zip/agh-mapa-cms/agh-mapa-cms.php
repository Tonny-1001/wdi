<?php
/**
 * Plugin Name: AGH – Mapa kampusu 3D (CMS)
 * Description: Oryginalna mapa AGH 3D/2D z edycją wszystkich budynków w panelu WordPress. Shortcode: [agh_mapa]
 * Version: 1.0.0
 * Author: Projekt mapy AGH – integracja CMS
 * Requires PHP: 7.4
 * Text Domain: agh-mapa-cms
 */

if (!defined('ABSPATH')) {
    exit;
}

final class AGH_Mapa_CMS {
    const CPT = 'agh_budynek';
    const INITIAL_OPTION = 'agh_mapa_cms_imported_v1';
    const GLOBALS_OPTION = 'agh_mapa_cms_globals_v1';

    public static function init() {
        add_action('init', [__CLASS__, 'register_type']);
        add_action('add_meta_boxes_' . self::CPT, [__CLASS__, 'add_metabox']);
        add_action('save_post_' . self::CPT, [__CLASS__, 'save_building']);
        add_action('wp_ajax_agh_map_view', [__CLASS__, 'serve_map']);
        add_action('wp_ajax_nopriv_agh_map_view', [__CLASS__, 'serve_map']);
        add_shortcode('agh_mapa', [__CLASS__, 'shortcode']);
        add_action('admin_menu', [__CLASS__, 'help_page']);
        add_filter('manage_' . self::CPT . '_posts_columns', [__CLASS__, 'columns']);
        add_action('manage_' . self::CPT . '_posts_custom_column', [__CLASS__, 'column_value'], 10, 2);
    }

    public static function register_type() {
        register_post_type(self::CPT, [
            'labels' => [
                'name' => 'Budynki AGH',
                'singular_name' => 'Budynek AGH',
                'menu_name' => 'Budynki AGH',
                'add_new' => 'Dodaj budynek',
                'add_new_item' => 'Dodaj budynek AGH',
                'edit_item' => 'Edytuj budynek AGH',
                'new_item' => 'Nowy budynek AGH',
                'all_items' => 'Wszystkie budynki',
                'search_items' => 'Szukaj budynków',
                'not_found' => 'Nie znaleziono budynków',
            ],
            'public' => false,
            'publicly_queryable' => false,
            'show_ui' => true,
            'show_in_menu' => true,
            'show_in_rest' => false,
            'exclude_from_search' => true,
            'menu_icon' => 'dashicons-location-alt',
            'menu_position' => 25,
            'supports' => ['title', 'editor'],
            'has_archive' => false,
        ]);
    }

    /** First activation only: load all 81 supplied buildings into posts + postmeta. */
    public static function activate() {
        self::register_type();
        if (get_option(self::INITIAL_OPTION)) {
            return;
        }

        $path = plugin_dir_path(__FILE__) . 'data/initial.json';
        $seed = is_readable($path) ? json_decode(file_get_contents($path), true) : null;
        if (!is_array($seed) || empty($seed['buildings']) || !is_array($seed['buildings'])) {
            return;
        }

        // Do not duplicate buildings on reactivation or on an interrupted import.
        $already = get_posts([
            'post_type' => self::CPT,
            'post_status' => 'any',
            'posts_per_page' => 1,
            'fields' => 'ids',
        ]);
        if ($already) {
            return;
        }

        update_option(self::GLOBALS_OPTION, isset($seed['globals']) ? $seed['globals'] : [], false);
        $created = 0;
        foreach ($seed['buildings'] as $b) {
            $post_id = wp_insert_post([
                'post_type' => self::CPT,
                'post_status' => 'publish',
                'post_title' => (string) ($b['name'] ?? $b['c'] ?? ''),
                'post_content' => (string) ($b['description'] ?? ''),
                'menu_order' => (int) ($b['order'] ?? $created),
            ], true);
            if (is_wp_error($post_id) || !$post_id) {
                continue;
            }
            $fields = [
                'code' => $b['c'] ?? '',
                'category' => $b['cat'] ?? 'Dydaktyka',
                'kind' => $b['k'] ?? 'r',
                'units' => $b['u'] ?? [],
                'hours' => $b['hours'] ?? '',
                'lat' => $b['ll'][0] ?? '',
                'lng' => $b['ll'][1] ?? '',
                'source' => $b['source'] ?? '',
                'coord_status' => $b['coord_status'] ?? 'estimated',
                'x' => $b['x'] ?? '',
                'y' => $b['y'] ?? '',
                'lx' => $b['lx'] ?? '',
                'lz' => $b['lz'] ?? '',
                'polygons' => $b['p'] ?? [],
                'unit_indexes' => $b['n'] ?? [],
            ];
            foreach ($fields as $key => $value) {
                update_post_meta($post_id, '_agh_' . $key, $value);
            }
            $created++;
        }
        if ($created === count($seed['buildings'])) {
            update_option(self::INITIAL_OPTION, '81-building-seed-v1', false);
        }
    }

    private static function val($post_id, $name, $default = '') {
        $v = get_post_meta($post_id, '_agh_' . $name, true);
        return ($v === '' || $v === null) ? $default : $v;
    }

    private static function input($name, $value, $placeholder = '') {
        printf(
            '<input class="regular-text" type="text" name="agh_%1$s" id="agh_%1$s" value="%2$s" placeholder="%3$s">',
            esc_attr($name), esc_attr((string) $value), esc_attr($placeholder)
        );
    }

    private static function row($name, $title, $content, $description = '') {
        echo '<tr><th scope="row"><label for="agh_' . esc_attr($name) . '">' . esc_html($title) . '</label></th><td>' . $content;
        if ($description !== '') {
            echo '<p class="description">' . esc_html($description) . '</p>';
        }
        echo '</td></tr>';
    }

    public static function add_metabox($post) {
        add_meta_box('agh_building_details', 'Dane budynku i pineski (CMS)', [__CLASS__, 'render_metabox'], self::CPT, 'normal', 'high');
    }

    public static function render_metabox($post) {
        wp_nonce_field('agh_save_building', 'agh_building_nonce');
        echo '<p><strong>Nazwa budynku</strong> to tytuł na górze edytora. <strong>Opis dodatkowy</strong> wpisz do głównego edytora tekstu. Zmiany są widoczne na mapie po zapisaniu/odświeżeniu.</p>';
        echo '<table class="form-table"><tbody>';
        $fields = [
            ['code', 'Oznaczenie budynku', 'np. A-0, DS-1'],
            ['hours', 'Godziny otwarcia / dziekanat', 'np. Pn–Pt: 7:00–20:00'],
            ['lat', 'Szerokość geograficzna (WGS84)', 'np. 50.06473'],
            ['lng', 'Długość geograficzna (WGS84)', 'np. 19.92342'],
            ['source', 'Źródło lokalizacji (URL)', 'https://...'],
        ];
        foreach ($fields as $entry) {
            ob_start();
            self::input($entry[0], self::val($post->ID, $entry[0]), $entry[2]);
            $content = ob_get_clean();
            $hint = in_array($entry[0], ['lat', 'lng'], true) ? 'Dla poprawnego wyświetlania pineski wpisz liczbę (można użyć przecinka).' : '';
            self::row($entry[0], $entry[1], $content, $hint);
        }
        $cat = self::val($post->ID, 'category', 'Dydaktyka');
        $cats = ['Dydaktyka' => 'Dydaktyka', 'Akademiki' => 'Akademiki', 'Sport/Kultura' => 'Sport/Kultura', 'Usługi' => 'Usługi'];
        $options = '<select name="agh_category" id="agh_category">';
        foreach ($cats as $key => $label) {
            $options .= '<option value="' . esc_attr($key) . '"' . selected($cat, $key, false) . '>' . esc_html($label) . '</option>';
        }
        self::row('category', 'Kategoria / filtr', $options . '</select>');

        $kind = self::val($post->ID, 'kind', 'r');
        $kinds = ['r' => 'Czerwona – standardowa', 'g' => 'Zielona – akademiki', 't' => 'Turkusowa – specjalna'];
        $options = '<select name="agh_kind" id="agh_kind">';
        foreach ($kinds as $key => $label) {
            $options .= '<option value="' . esc_attr($key) . '"' . selected($kind, $key, false) . '>' . esc_html($label) . '</option>';
        }
        self::row('kind', 'Wygląd pineski', $options . '</select>');

        $coord = self::val($post->ID, 'coord_status', 'estimated');
        $options = '<select name="agh_coord_status" id="agh_coord_status">';
        foreach (['estimated' => 'Oszacowana lokalizacja', 'checked' => 'Zweryfikowana lokalizacja'] as $key => $label) {
            $options .= '<option value="' . esc_attr($key) . '"' . selected($coord, $key, false) . '>' . esc_html($label) . '</option>';
        }
        self::row('coord_status', 'Dokładność położenia', $options . '</select>');

        $units = self::val($post->ID, 'units', []);
        $units = is_array($units) ? implode("\n", $units) : (string) $units;
        self::row('units', 'Wydziały / jednostki', '<textarea id="agh_units" name="agh_units" rows="6" class="large-text">' . esc_textarea($units) . '</textarea>', 'Jedna jednostka w osobnym wierszu. Wyświetlają się w panelu budynku.');
        echo '</tbody></table>';
        echo '<details><summary style="cursor:pointer;font-weight:600;padding:12px 0">Ustawienia zaawansowane: oryginalna geometria / kalibracja / kolejność</summary>';
        echo '<p>Te pola zachowują geometrię i dane z dostarczonego pliku HTML. Do normalnej edycji pinesek wystarczą współrzędne WGS84 powyżej.</p><table class="form-table"><tbody>';
        foreach (['x'=>'Plan: X', 'y'=>'Plan: Y', 'lx'=>'Etykieta: LX', 'lz'=>'Etykieta: LZ'] as $key=>$title) {
            ob_start(); self::input($key, self::val($post->ID, $key)); $content = ob_get_clean();
            self::row($key, $title, $content);
        }
        $p = self::val($post->ID, 'polygons', []);
        $n = self::val($post->ID, 'unit_indexes', []);
        self::row('polygons', 'Oryginalna geometria JSON', '<textarea id="agh_polygons" name="agh_polygons" rows="6" class="large-text code">' . esc_textarea(wp_json_encode($p, JSON_UNESCAPED_UNICODE)) . '</textarea>', 'Zapis wymaga poprawnej tablicy JSON. Nie zmieniaj, jeśli nie jest to potrzebne.');
        self::row('unit_indexes', 'Historyczne indeksy jednostek JSON', '<textarea id="agh_unit_indexes" name="agh_unit_indexes" rows="2" class="large-text code">' . esc_textarea(wp_json_encode($n)) . '</textarea>', 'Zachowane z oryginalnej mapy; lista jednostek powyżej jest nadrzędna.');
        ob_start(); self::input('order', (int) $post->menu_order); $content = ob_get_clean();
        self::row('order', 'Kolejność budynku w katalogu', $content, 'Mniejszy numer oznacza wcześniejszą pozycję.');
        echo '</tbody></table></details>';
    }

    public static function save_building($post_id) {
        if (!isset($_POST['agh_building_nonce']) ||
            !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['agh_building_nonce'])), 'agh_save_building') ||
            (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) ||
            wp_is_post_revision($post_id) ||
            !current_user_can('edit_post', $post_id)) {
            return;
        }
        $keys = ['code', 'hours', 'lat', 'lng', 'source', 'category', 'kind', 'coord_status', 'x', 'y', 'lx', 'lz'];
        foreach ($keys as $key) {
            if (!isset($_POST['agh_' . $key]) || is_array($_POST['agh_' . $key])) {
                continue;
            }
            $v = sanitize_text_field(wp_unslash($_POST['agh_' . $key]));
            if (in_array($key, ['lat','lng','x','y','lx','lz'], true)) {
                $v = str_replace(',', '.', trim($v));
                if ($v !== '' && !is_numeric($v)) {
                    continue;
                }
            } elseif ($key === 'source') {
                $v = esc_url_raw($v);
            } elseif ($key === 'category') {
                if (!in_array($v, ['Dydaktyka','Akademiki','Sport/Kultura','Usługi'], true)) continue;
            } elseif ($key === 'kind') {
                if (!in_array($v, ['r','g','t'], true)) continue;
            } elseif ($key === 'coord_status') {
                if (!in_array($v, ['estimated','checked'], true)) continue;
            }
            update_post_meta($post_id, '_agh_' . $key, $v);
        }
        if (isset($_POST['agh_units']) && is_string($_POST['agh_units'])) {
            $rows = preg_split('/\r\n|\r|\n/', wp_unslash($_POST['agh_units']));
            $units = [];
            foreach ($rows as $unit) {
                $unit = sanitize_text_field(trim($unit));
                if ($unit !== '') $units[] = $unit;
            }
            update_post_meta($post_id, '_agh_units', $units);
        }
        foreach (['polygons', 'unit_indexes'] as $key) {
            if (isset($_POST['agh_' . $key]) && is_string($_POST['agh_' . $key])) {
                $arr = json_decode(wp_unslash($_POST['agh_' . $key]), true);
                if (is_array($arr) && array_values($arr) === $arr) {
                    update_post_meta($post_id, '_agh_' . $key, $arr);
                }
            }
        }
        if (isset($_POST['agh_order']) && is_scalar($_POST['agh_order'])) {
            $order = (int) sanitize_text_field(wp_unslash($_POST['agh_order']));
            if ((int) get_post_field('menu_order', $post_id) !== $order) {
                // Avoid a recursive save_post call.
                remove_action('save_post_' . self::CPT, [__CLASS__, 'save_building']);
                wp_update_post(['ID' => $post_id, 'menu_order' => $order]);
                add_action('save_post_' . self::CPT, [__CLASS__, 'save_building']);
            }
        }
    }

    private static function map_data() {
        $globals = get_option(self::GLOBALS_OPTION, []);
        if (!is_array($globals)) $globals = [];
        $globals['B'] = [];
        $posts = get_posts([
            'post_type' => self::CPT,
            'post_status' => 'publish',
            'posts_per_page' => -1,
            'orderby' => ['menu_order' => 'ASC', 'ID' => 'ASC'],
            'suppress_filters' => true,
        ]);
        foreach ($posts as $p) {
            $lat = self::val($p->ID, 'lat');
            $lng = self::val($p->ID, 'lng');
            // A pin cannot be placed without valid geographic coordinates.
            if (!is_numeric($lat) || !is_numeric($lng) || (float)$lat < -90 || (float)$lat > 90 || (float)$lng < -180 || (float)$lng > 180) {
                continue;
            }
            $units = self::val($p->ID, 'units', []);
            $polygons = self::val($p->ID, 'polygons', []);
            $indexes = self::val($p->ID, 'unit_indexes', []);
            $globals['B'][] = [
                'c' => (string) self::val($p->ID, 'code', 'ID-' . $p->ID),
                'k' => (string) self::val($p->ID, 'kind', 'r'),
                'n' => is_array($indexes) ? $indexes : [],
                'p' => is_array($polygons) ? $polygons : [],
                'lx' => (float) self::val($p->ID, 'lx', 0),
                'lz' => (float) self::val($p->ID, 'lz', 0),
                'x' => (float) self::val($p->ID, 'x', 0),
                'y' => (float) self::val($p->ID, 'y', 0),
                'u' => is_array($units) ? array_values($units) : [],
                'cat' => (string) self::val($p->ID, 'category', 'Dydaktyka'),
                'name' => (string) get_post_field('post_title', $p->ID, 'raw'),
                'hours' => (string) self::val($p->ID, 'hours'),
                'll' => [(float)$lat, (float)$lng],
                'source' => (string) self::val($p->ID, 'source'),
                'coord_status' => (string) self::val($p->ID, 'coord_status', 'estimated'),
                'description' => trim(wp_strip_all_tags((string) get_post_field('post_content', $p->ID, 'raw'))),
            ];
        }
        return $globals;
    }

    public static function serve_map() {
        $template = plugin_dir_path(__FILE__) . 'assets/map-template.html';
        if (!is_readable($template)) {
            status_header(500);
            echo 'Brak szablonu mapy AGH.';
            exit;
        }
        $data = self::map_data();
        $json = wp_json_encode($data,
            JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);
        if ($json === false) {
            status_header(500);
            echo 'Nie udało się pobrać danych mapy.';
            exit;
        }
        nocache_headers();
        header('Content-Type: text/html; charset=UTF-8');
        header('X-Content-Type-Options: nosniff');
        echo str_replace('__AGH_BUILDINGS_JSON__', $json, file_get_contents($template));
        exit;
    }

    public static function shortcode($atts) {
        $atts = shortcode_atts(['tryb' => 'pelny', 'wysokosc' => '800px'], $atts, 'agh_mapa');
        $src = add_query_arg('action', 'agh_map_view', admin_url('admin-ajax.php'));
        $full = $atts['tryb'] !== 'osadzony';
        $css = $full
            ? 'position:fixed;inset:0;width:100vw;height:100vh;height:100dvh;z-index:2147483000;border:0;background:#0d1424;display:block;margin:0;padding:0;'
            : 'display:block;width:100%;height:' . esc_attr(preg_match('/^\d+(px|vh|dvh|rem|%)$/', $atts['wysokosc']) ? $atts['wysokosc'] : '800px') . ';min-height:450px;border:0;background:#0d1424;';
        return '<iframe title="Mapa 3D kampusu AGH" loading="eager" referrerpolicy="strict-origin-when-cross-origin" style="' . esc_attr($css) . '" src="' . esc_url($src) . '"></iframe>';
    }

    public static function columns($columns) {
        return [
            'cb' => $columns['cb'] ?? '',
            'title' => 'Nazwa budynku',
            'agh_code' => 'Kod',
            'agh_cat' => 'Kategoria',
            'agh_pos' => 'Współrzędne',
            'date' => 'Data',
        ];
    }

    public static function column_value($column, $post_id) {
        if ($column === 'agh_code') echo esc_html((string)self::val($post_id, 'code'));
        if ($column === 'agh_cat') echo esc_html((string)self::val($post_id, 'category'));
        if ($column === 'agh_pos') {
            $lat = self::val($post_id, 'lat');
            $lng = self::val($post_id, 'lng');
            echo ($lat !== '' && $lng !== '') ? esc_html($lat . ', ' . $lng) : '<em>Brak – pineska ukryta</em>';
        }
    }

    public static function help_page() {
        add_submenu_page('edit.php?post_type=' . self::CPT, 'Ustawienia mapy AGH', 'Jak wstawić mapę', 'manage_options', 'agh-mapa-instrukcja', [__CLASS__, 'help_content']);
    }

    public static function help_content() {
        $url = add_query_arg('action', 'agh_map_view', admin_url('admin-ajax.php'));
        echo '<div class="wrap"><h1>Mapa kampusu AGH – CMS</h1>';
        echo '<p>Wtyczka wczytuje dane budynków z bazy WordPress. Po aktywacji importuje 81 budynków z dostarczonego pliku. Zapisane zmiany nie wymagają modyfikacji HTML.</p>';
        echo '<ol><li>Otwórz <strong>Budynki AGH → Wszystkie budynki</strong> i wybierz budynek do edycji.</li>';
        echo '<li>Zmień nazwę, jednostki, godziny, kategorię lub współrzędne i kliknij <strong>Aktualizuj</strong>.</li>';
        echo '<li>Utwórz stronę WordPress, np. „Mapa kampusu”, i wstaw blok <strong>Krótki kod</strong> z treścią <code>[agh_mapa]</code>.</li>';
        echo '<li>Opublikuj i otwórz stronę. Domyślnie mapa zajmuje całe okno jak w oryginalnym pliku.</li></ol>';
        echo '<p>Dla mapy umieszczonej wewnątrz strony: <code>[agh_mapa tryb="osadzony" wysokosc="800px"]</code>.</p>';
        echo '<p>Bezpośredni adres mapy: <a href="' . esc_url($url) . '" target="_blank" rel="noopener">' . esc_html($url) . '</a></p>';
        echo '<p>Budynki przechowywane są w tabelach <code>wp_posts</code> i <code>wp_postmeta</code> (prefiks może być inny). Kopia zapasowa WordPress powinna obejmować bazę danych i pliki wtyczki.</p>';
        echo '<p><strong>Uwaga:</strong> żeby nowa pineska się pojawiła, budynek musi być <strong>Opublikowany</strong> i mieć prawidłowe współrzędne WGS84.</p></div>';
    }
}

AGH_Mapa_CMS::init();
register_activation_hook(__FILE__, ['AGH_Mapa_CMS', 'activate']);
